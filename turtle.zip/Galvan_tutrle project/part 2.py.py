

import turtle

x = turtle.Turtle()
y = turtle.Turtle()
x.speed(20)



z = turtle.Screen()
z.colormode(255)
z.bgcolor(120,45, 100)

def shape(AnyTurtle, sidelength, n):
    for i in range(n):
        AnyTurtle.forward(sidelength)
        AnyTurtle.right(360/n)

r = 140
g = 180
b = 200

for i in range(200, 1, -10):
    x.color(r, g, b)
    shape(x, i, 4)
    r = r + 1
    b = b - 1
   

