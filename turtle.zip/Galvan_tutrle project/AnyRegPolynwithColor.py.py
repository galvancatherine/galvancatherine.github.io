
import turtle

def AnyRegPoly():
    sides = int(input('how many sides does it take to make a regular polygon: '))
    length = int(input('how long do you want them to be on each side: '))
    angle = sides - 2
    angle_1 = angle *180
    real_angle = 180 - (angle_1/sides)
    turt = turtle.Turtle('turtle')
    for i in range(sides):
        turt.forward(length)
        turt.right(real_angle)

sb = turtle.Turtle('turtle')
sb.speed(100)
z = turtle.Screen()
z.colormode(255)
z.bgcolor(0,70, 0)

wn = turtle.Screen()
wn = colormode(255)
r = 1
g = 1
b = 1

          

    
