import turtle

x = turtle.Turtle ()
x.speed(0)
def square(n,theta):
    for i in range (5):
        x.forward(n)
        x.right(theta)
        

square(100,90)




x = turtle.Turtle ()

def nonagon (n,theta):
    for i in range (10):
        x.forward(n)
        x.right(theta)
        x.left (n)
        


nonagon(100,60)


x = turtle.Turtle ()

def decagon(n,theta):
    for i in range (11):
        x.forward(n)
        x.right(theta)
        x.left (n)
        


decagon (100,64)



x = turtle.Turtle ()

def triangle (n,theta):
    for i in range (4):
        x.forward(n)
        x.right(theta)
        x.right (n)
        


triangle (100,20)


x = turtle.Turtle ()

def star (n,theta):
    for i in range (5):
        x.forward(n)
        x.right(theta)


star(100,144)

x = turtle.Turtle ()

def pentagon (n,theta):
    for i in range (7):
        x.forward(n)
        x.right(theta)
        x.left (n)


pentagon (100,40)


x = turtle.Turtle ()

def hexagon (n,theta):
    for i in range (7):
        x.forward(n)
        x.right(theta)


hexagon (100,60)

