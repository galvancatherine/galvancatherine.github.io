
import turtle

def shape(s, n, turt):
    xy.pu()
    xy.goto(-s/2, s/2)
    xy.pd()
    for i in range (n):

        turt.forward(s)
        turt.right(360/n)

xy = turtle.Turtle()
xy.speed(0)
z = turtle.Screen()
z.colormode(255)
z.bgcolor(150,45, 150)

for i in range (7, 560, 10):

    shape(i, 4, xy)

