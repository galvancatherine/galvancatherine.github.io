import turtle 
z = turtle.Screen()
z.colormode(255)
z.bgcolor(120,45, 100)
cg = turtle.Turtle()
cg.speed(0)
cg.pencolor("black")

for i in range(50):
    cg.forward(300)
    cg.left(130) 
    
cg.pencolor("pink")
for i in range(150):
    cg.forward(150)
    cg.left(50)


